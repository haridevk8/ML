# From DevOps to MLOPS: Integrate Machine Learning Models using Jenkins and Docker

https://towardsdatascience.com/from-devops-to-mlops-integrate-machine-learning-models-using-jenkins-and-docker-79034dbedf1
